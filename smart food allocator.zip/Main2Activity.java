package com.example.smart_food_allocator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {
    private EditText ed1,ed2;
    private TextView tv1,tv2;
    private RadioGroup rg;
    private RadioButton rb1,rb2;
    private Button bt1,bt2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        ed1=findViewById(R.id.ed1);
        ed2=findViewById(R.id.ed2);
        tv1=findViewById(R.id.tv1);
        tv2=findViewById(R.id.tv2);
        rg=findViewById(R.id.radioGroup);
        rb1=findViewById(R.id.rb1);
        rb2=findViewById(R.id.rb2);
        bt1=findViewById(R.id.bt1);
        bt2=findViewById(R.id.bt2);
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ed1.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "enter your username", Toast.LENGTH_SHORT).show();
                }
                if(ed2.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "enter your password", Toast.LENGTH_SHORT).show();
                }
                Intent intent=new Intent(Main2Activity.this,Donarpage.class);
                startActivity(intent);

            }
        });
        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Main2Activity.this,SelectActivity.class);
                startActivity(intent);

            }
        });
    }
}
